package tmoney.co.kr.hxz.svcjoin.vo.rsdc;

public class RsdcAuthUpdReqVO {
}
