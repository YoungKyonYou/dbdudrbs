package tmoney.co.kr.hxz.svcjoin.vo.svccncn;

public class SvcCncnRspVO {
}
